const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.static("public"));

mongoose.connect("mongodb://127.0.0.1:27017/contactDB")
  .then(() => console.log("MongoDB Connected"))
  .catch((err) => console.log(err));

const contactSchema = new mongoose.Schema({
  name: String,
  email: String,
  subject: String,
  message: String,
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

const Contact = mongoose.model("Contact", contactSchema);

app.post("/api/contact", async (req, res) => {
  try {
    const { name, email, subject, message } = req.body;

    if (!name || !email || !message) {
      return res
        .status(400)
        .json({ success: false, message: "Required fields missing" });
    } else {
      const newContact = new Contact({
        name,
        email,
        subject,
        message,
      });

      await newContact.save();

      res.status(200).json({ success: true, message: "Data saved!" });
    }
  } catch (error) {
    res.status(500).json({ success: false, error });
  }
});

app.listen(5000, () => {
  console.log("Server running on http://localhost:5000");
});
